import java.io.IOException;
//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        //TIP Press <shortcut actionId="ShowIntentionActions"/> with your caret at the highlighted text
        // to see how IntelliJ IDEA suggests fixing it.
        System.out.println("Welcome to the Video Processor");
        //TIP Press <shortcut actionId="Debug"/> to start debugging your code. We have set one <icon src="AllIcons.Debugger.Db_set_breakpoint"/> breakpoint
        // for you, but you can always add more by pressing <shortcut actionId="ToggleLineBreakpoint"/>.




        VideoImporter bob = new VideoImporter();
        while (!bob.hasVideo()) {
            try {
                Thread.sleep(100); // loops over and over until the file is selected
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }


        // get the selected file path
        JavaToPythonVideoPlayer javaToPython = new JavaToPythonVideoPlayer();


        javaToPython.JavaToPythonVideo(bob.getFilePath());



    }
}
